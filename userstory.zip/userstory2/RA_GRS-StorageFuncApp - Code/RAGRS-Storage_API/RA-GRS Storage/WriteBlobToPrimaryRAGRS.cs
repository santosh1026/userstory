using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.RetryPolicies;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading.Tasks;

namespace AzureBlobStorageRAGRS.RAGRS
{
    public static class WriteBlobToPrimaryRAGRS
    {
        [FunctionName("WriteBlobToPrimaryRAGRS")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var saveBlobRequest = JsonConvert.DeserializeObject<SaveBlobRequest>(requestBody);

            var storageConnectionString = System.Environment.GetEnvironmentVariable("RaGrsStorageConnectionString");

            // Create a client for blob storage
            var storageAccount = CloudStorageAccount.Parse(storageConnectionString);

            // Create blob client
            var blobClient = storageAccount.CreateCloudBlobClient();
            
            // Use only primary region for writting blob
            blobClient.DefaultRequestOptions.LocationMode = LocationMode.PrimaryOnly;

            // Create blob container client object
            var blobContainer = blobClient.GetContainerReference("samplecontainer");

            // Get blob reference
            var blobReference = blobContainer.GetBlockBlobReference(saveBlobRequest.BlobName);

            // Upload blob's contents
            var bytes = Convert.FromBase64String(saveBlobRequest.BlobContentBase64);

            using (var ms = new MemoryStream(bytes))
            {
                await blobReference.UploadFromStreamAsync(ms);

                return new OkObjectResult("Blob saved successfully.");
            }
        }
    }
}