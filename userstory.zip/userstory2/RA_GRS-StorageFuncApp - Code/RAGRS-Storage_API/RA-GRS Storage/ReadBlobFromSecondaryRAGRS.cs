using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.RetryPolicies;
using System;
using System.IO;
using System.Threading.Tasks;

namespace AzureBlobStorageRAGRS.RAGRS
{
    public static class ReadBlobFromSecondaryRAGRS
    {
        [FunctionName("ReadBlobFromSecondaryRAGRS")]
        public static async Task<IActionResult> Run(
           [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req)
        {
            string blobName = req.Query["blobName"];

            var storageConnectionString = System.Environment.GetEnvironmentVariable("RaGrsStorageConnectionString");

            // Create a client for blob storage
            var storageAccount = CloudStorageAccount.Parse(storageConnectionString);

            // Create blob client
            var blobClient = storageAccount.CreateCloudBlobClient();

            // Switch blob client to secondary replication
            blobClient.DefaultRequestOptions.LocationMode = LocationMode.SecondaryOnly;

            // Create blob container client object
            var blobContainer = blobClient.GetContainerReference("samplecontainer");

            // Get blob reference
            var blobReference = blobContainer.GetBlockBlobReference(blobName);

            // Download blob's contents
            using (var ms = new MemoryStream())
            {
                await blobReference.DownloadToStreamAsync(ms);

                return new FileContentResult(ms.ToArray(), "application/octet-stream")
                {
                    FileDownloadName = blobName
                };
            }
        }
    }
}